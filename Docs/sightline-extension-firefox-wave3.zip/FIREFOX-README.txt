Sightline Firefox unpacked package (SIH26171)

1. about:debugging → This Firefox → Load Temporary Add-on
2. Select manifest.json in this directory
3. Live validation on this build host may still be unverified if Firefox is absent.
4. Chrome uses ../extension-build/ with the Chromium manifest.
